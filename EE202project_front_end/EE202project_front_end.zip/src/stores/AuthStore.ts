import { defineStore } from 'pinia';
import AuthService from '../services/AuthService';

interface User {
  token: string;
  type: string;
  employeeId: number;
  username: string;
  email: string;
  employeeType: string;
  authorities: string[];
}

interface AuthState {
  user: User | null;
}

export const useAuthStore = defineStore('auth', {
  state: (): AuthState => ({
    user: JSON.parse(localStorage.getItem('user') || 'null'),
  }),
  getters: {
    loggedIn: (state) => !!state.user,
    currentUser: (state) => state.user,
  },
  actions: {
    async login(user: any) {
      const response = await AuthService.login(user);
      this.user = response;
      return response;
    },
    logout() {
      AuthService.logout();
      this.user = null;
    },
    async register(user: any) {
      return AuthService.register(user);
    },
  },
});
<template>
  <div class="outbound-view">
    <el-row :gutter="20">
      <el-col :span="12">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>工單列表</span>
              <el-button type="primary" @click="showAddWorkOrderDialog = true; fetchAvailableMaterials()">新增工單</el-button>
            </div>
          </template>
          <el-table :data="workOrders" style="width: 100%" v-loading="loadingWorkOrders">
            <el-table-column prop="woId" label="ID" width="80"></el-table-column>
            <el-table-column prop="woNumber" label="工單號碼"></el-table-column>
            <el-table-column prop="materialName" label="生產物料"></el-table-column>
            <el-table-column prop="requiredQuantity" label="需求數量" width="120"></el-table-column>
            <el-table-column prop="status" label="狀態" width="100"></el-table-column>
            <el-table-column label="操作" width="150">
              <template #default="scope">
                <el-button link type="primary" size="small" @click="viewWorkOrderDetails(scope.row)">詳情</el-button>
                <el-button link type="danger" size="small" @click="deleteWorkOrder(scope.row.woId)">刪除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>

      <el-col :span="12">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>領料操作</span>
              <el-button type="success" @click="showCreatePickingOrderDialog = true; resetPickingOrderForm(); fetchUsersForDropdown(); fetchAvailableMaterials();">建立領料單</el-button>
            </div>
          </template>
          <el-form :model="pickingForm" label-width="100px">
            <el-form-item label="工單ID">
              <el-select v-model.number="pickingForm.woId" placeholder="請選擇工單" style="width: 100%;" filterable>
                <el-option
                  v-for="wo in workOrders"
                  :key="wo.woId"
                  :label="`${wo.woNumber} (${wo.materialName})`"
                  :value="wo.woId"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="物料ID">
              <el-select v-model.number="pickingForm.materialId" placeholder="請選擇物料" style="width: 100%;" filterable>
                <el-option
                  v-for="mat in availableMaterials"
                  :key="mat.materialId"
                  :label="`${mat.materialName} (ID: ${mat.materialId})`"
                  :value="mat.materialId"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="領料數量">
              <el-input-number v-model="pickingForm.requestedQuantity" :min="1"></el-input-number>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="processPicking">執行領料</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" style="margin-top: 20px;">
      <el-col :span="24">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>所有領料明細列表</span>
            </div>
          </template>
          <el-table :data="pickingMaterials" style="width: 100%" v-loading="loadingPickingMaterials">
            <el-table-column prop="woMaterialId" label="領料ID" width="80"></el-table-column>
            <el-table-column prop="materialName" label="物料名稱"></el-table-column>
            <el-table-column prop="requestedQuantity" label="需求數量"></el-table-column>
            <el-table-column prop="issuedQuantity" label="已發料數量"></el-table-column>
            <el-table-column prop="status" label="狀態"></el-table-column>
            <el-table-column label="操作" width="150">
              <template #default="scope">
                <el-button link type="primary" size="small" @click="viewPickingMaterialDetails(scope.row)">詳情</el-button>
                <el-button link type="danger" size="small" @click="deletePickingMaterial(scope.row.woMaterialId)">刪除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <!-- 新增工單 Dialog -->
    <el-dialog v-model="showAddWorkOrderDialog" title="新增工單" width="600">
      <el-form :model="newWorkOrder" :rules="addWorkOrderRules" ref="addWorkOrderFormRef" label-width="120px">
        <el-form-item label="工單號碼" prop="woNumber">
          <el-input v-model="newWorkOrder.woNumber"></el-input>
        </el-form-item>
        <el-form-item label="生產物料" prop="materialId">
          <el-select v-model.number="newWorkOrder.materialId" placeholder="請選擇物料" style="width: 100%;" filterable v-if="availableMaterials.length > 0">
            <el-option
              v-for="mat in availableMaterials"
              :key="mat.materialId"
              :label="mat.materialName"
              :value="mat.materialId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="需求數量" prop="requiredQuantity">
          <el-input-number v-model="newWorkOrder.requiredQuantity" :min="1"></el-input-number>
        </el-form-item>
        <el-form-item label="狀態" prop="status">
          <el-select v-model="newWorkOrder.status" placeholder="請選擇狀態" style="width: 100%;">
            <el-option label="進行中" value="PENDING"></el-option>
            <el-option label="已完成" value="COMPLETED"></el-option>
            <el-option label="庫存不夠" value="OUT_OF_STOCK"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showAddWorkOrderDialog = false">取消</el-button>
          <el-button type="primary" @click="addWorkOrder">
            新增
          </el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 工單詳情 Dialog -->
    <el-dialog v-model="showWorkOrderDetailsDialog" title="工單詳情" width="700">
      <div v-if="selectedWorkOrder">
        <p><strong>工單ID:</strong> {{ selectedWorkOrder.woId }}</p>
        <p><strong>工單號碼:</strong> {{ selectedWorkOrder.woNumber }}</p>
        <p><strong>生產物料:</strong> {{ selectedWorkOrder.material?.materialName }}</p>
        <p><strong>需求數量:</strong> {{ selectedWorkOrder.requiredQuantity }}</p>
        <p><strong>狀態:</strong> {{ selectedWorkOrder.status }}</p>
        <p><strong>建立時間:</strong> {{ selectedWorkOrder.createdAt }}</p>
        <p><strong>更新時間:</strong> {{ selectedWorkOrder.updatedAt }}</p>

        <h4>領料明細:</h4>
        <el-table :data="selectedWorkOrderMaterials" style="width: 100%">
          <el-table-column prop="woMaterialId" label="領料ID" width="80"></el-table-column>
          <el-table-column prop="material.materialName" label="物料名稱"></el-table-column>
          <el-table-column prop="requestedQuantity" label="需求數量"></el-table-column>
          <el-table-column prop="issuedQuantity" label="已發料數量"></el-table-column>
          <el-table-column prop="status" label="狀態"></el-table-column>
        </el-table>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showWorkOrderDetailsDialog = false">關閉</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 領料明細詳情 Dialog -->
    <el-dialog v-model="showPickingMaterialDetailsDialog" title="領料明細詳情" width="600">
      <div v-if="selectedPickingMaterial">
        <p><strong>領料ID:</strong> {{ selectedPickingMaterial.woMaterialId }}</p>
        <p><strong>物料名稱:</strong> {{ selectedPickingMaterial.materialName }}</p>
        <p><strong>需求數量:</strong> {{ selectedPickingMaterial.requestedQuantity }}</p>
        <p><strong>已發料數量:</strong> {{ selectedPickingMaterial.issuedQuantity }}</p>
        <p><strong>狀態:</strong> {{ selectedPickingMaterial.status }}</p>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showPickingMaterialDetailsDialog = false">關閉</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 建立領料單 Dialog -->
    <el-dialog v-model="showCreatePickingOrderDialog" title="建立領料單" width="700">
      <el-form :model="newPickingOrder" label-width="120px">
        <el-form-item label="供應商名稱">
          <el-input v-model="newPickingOrder.supplierName"></el-input>
        </el-form-item>
        <el-form-item label="領料單號碼">
          <el-input v-model="newPickingOrder.orderNumber"></el-input>
        </el-form-item>
        <el-form-item label="預計收貨日期">
          <el-date-picker v-model="newPickingOrder.expectedReceiptDate" type="date" placeholder="選擇日期" style="width: 100%;"></el-date-picker>
        </el-form-item>
        <el-form-item label="經手人">
          <el-select v-model.number="newPickingOrder.handledByUserId" placeholder="選擇經手人" style="width: 100%;">
            <el-option
              v-for="user in users"
              :key="user.userId"
              :label="user.username"
              :value="user.userId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="狀態">
          <el-select v-model="newPickingOrder.status" placeholder="選擇狀態">
            <el-option label="草稿" value="DRAFT"></el-option>
            <el-option label="已核准" value="APPROVED"></el-option>
            <el-option label="已完成" value="COMPLETED"></el-option>
            <el-option label="已取消" value="CANCELLED"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="備註">
          <el-input v-model="newPickingOrder.note" type="textarea"></el-input>
        </el-form-item>
        <el-form-item label="領料項目">
          <el-button type="primary" link @click="addPickingOrderItem">新增項目</el-button>
          <el-table :data="newPickingOrder.items" style="width: 100%; margin-top: 10px;">
            <el-table-column label="物料">
              <template #default="scope">
                <el-select v-model.number="scope.row.materialId" placeholder="選擇物料">
                  <el-option
                    v-for="mat in availableMaterials"
                    :key="mat.materialId"
                    :label="`${mat.materialName} (ID: ${mat.materialId})`"
                    :value="mat.materialId"
                  ></el-option>
                </el-select>
              </template>
            </el-table-column>
            <el-table-column label="預計數量">
              <template #default="scope">
                <el-input-number v-model="scope.row.expectedQuantity" :min="1"></el-input-number>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="80">
              <template #default="scope">
                <el-button link type="danger" @click="removePickingOrderItem(scope.$index)">刪除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showCreatePickingOrderDialog = false">取消</el-button>
          <el-button type="primary" @click="createPickingOrder">
            建立
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue'
import http from '../http-common'
import { ElMessage, ElMessageBox, FormInstance, FormRules } from 'element-plus'

interface WorkOrderDto {
  woId?: number;
  woNumber: string;
  materialId: number;
  materialName: string;
  requiredQuantity: number;
  status: string;
  createdAt?: string;
  updatedAt?: string;
}

interface WorkOrderMaterialDto {
  woMaterialId?: number;
  materialId: number;
  materialName: string;
  requestedQuantity: number;
  issuedQuantity?: number;
  status: string;
}

interface WorkOrderCreateDto {
  woNumber: string;
  materialId: number;
  requiredQuantity: number;
  status: string;
}

interface PickingRequestDto {
  woId: number;
  materialId: number;
  requestedQuantity: number;
}

interface UserDto {
  userId: number;
  username: string;
  fullName: string;
}

interface PickingOrderItem {
  materialId: number;
  expectedQuantity: number;
}

interface PickingOrder {
  pickingOrderId?: number;
  supplierName: string;
  orderNumber: string;
  expectedReceiptDate: string;
  handledByUserId?: number;
  handledBy?: string; // For display
  status: string;
  note?: string;
  items: PickingOrderItem[];
}

const workOrders = ref<WorkOrderDto[]>([])
const loadingWorkOrders = ref(false)
const showAddWorkOrderDialog = ref(false)
const newWorkOrder = ref<WorkOrderCreateDto>({
  woNumber: '',
  materialId: null, // 預設為 null，讓用戶選擇
  requiredQuantity: 0,
  status: 'PENDING', // 預設為 PENDING
})

const addWorkOrderFormRef = ref<FormInstance>() // 表單實例引用

const addWorkOrderRules = ref<FormRules>({
  woNumber: [
    { required: true, message: '請輸入工單號碼', trigger: 'blur' },
    { min: 3, max: 20, message: '長度在 3 到 20 個字符', trigger: 'blur' },
  ],
  materialId: [
    { required: true, message: '請選擇生產物料', trigger: 'change' },
  ],
  requiredQuantity: [
    { required: true, message: '請輸入需求數量', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (value === null || value === undefined || value === '') {
          callback(new Error('請輸入需求數量'));
        } else if (typeof value !== 'number' || isNaN(value)) {
          callback(new Error('需求數量必須為數字'));
        } else if (value <= 0) {
          callback(new Error('需求數量必須大於 0'));
        } else {
          callback();
        }
      },
      trigger: 'blur',
    },
  ],
  status: [
    { required: true, message: '請選擇狀態', trigger: 'change' },
  ],
})

const pickingForm = ref<PickingRequestDto>({
  woId: null as number | null,
  materialId: null as number | null,
  requestedQuantity: 1,
})

const showWorkOrderDetailsDialog = ref(false)
const selectedWorkOrder = ref<WorkOrderDto | null>(null)
const selectedWorkOrderMaterials = ref<WorkOrderMaterialDto[]>([])
const pickingMaterials = ref<WorkOrderMaterialDto[]>([]) // 新增：所有領料明細列表
const loadingPickingMaterials = ref(false) // 新增：領料明細列表加載狀態

const showPickingMaterialDetailsDialog = ref(false) // 新增：控制領料明細詳情對話框顯示
const selectedPickingMaterial = ref<WorkOrderMaterialDto | null>(null) // 新增：選中的領料明細

const availableMaterials = ref<Material[]>([]) // 可用的物料列表
const users = ref<UserDto[]>([]); // 新增：用於經手人下拉選單

const showCreatePickingOrderDialog = ref(false);
const newPickingOrder = ref<PickingOrder>({
  supplierName: '',
  orderNumber: '',
  expectedReceiptDate: '',
  handledByUserId: undefined,
  status: 'APPROVED', // Default to APPROVED
  note: '',
  items: [],
});

const API_BASE_URL = 'http://localhost:8082/api/workorder'
const MATERIAL_API_BASE_URL = 'http://localhost:8082/api/depot/materials'
const USER_API_BASE_URL = 'http://localhost:8082/api/users';
const PICKING_ORDER_API_BASE_URL = 'http://localhost:8082/api/picking-orders';

// Fetch work orders
const fetchWorkOrders = async () => {
  loadingWorkOrders.value = true
  try {
    const response = await http.get<WorkOrderDto[]>(API_BASE_URL)
    workOrders.value = response.data
  } catch (error: any) {
    console.error('Error fetching work orders:', error)
    ElMessage.error(`獲取工單失敗: ${error.response?.data || error.message}`)
  } finally {
    loadingWorkOrders.value = false
  }
}

// Fetch all users for dropdown
const fetchUsersForDropdown = async () => {
  try {
    const response = await http.get<UserDto[]>(USER_API_BASE_URL);
    users.value = response.data;
  } catch (error: any) {
    console.error('Error fetching users for dropdown:', error);
    ElMessage.error(`獲取使用者列表失敗: ${error.response?.data?.message || error.message}`);
  }
};

// Fetch all available materials
const fetchAvailableMaterials = async () => {
  try {
    const response = await http.get<Material[]>(MATERIAL_API_BASE_URL)
    availableMaterials.value = response.data
    console.log('Available Materials fetched:', availableMaterials.value); // 添加這行來檢查數據
  } catch (error: any) {
    console.error('Error fetching available materials:', error)
    ElMessage.error(`獲取可用物料列表失敗: ${error.response?.data || error.message}`)
  }
}

// Fetch all picking materials
const fetchAllPickingMaterials = async () => {
  loadingPickingMaterials.value = true
  try {
    const response = await http.get<WorkOrderMaterialDto[]>(`${API_BASE_URL}/materials`)
    pickingMaterials.value = response.data
  } catch (error: any) {
    console.error('Error fetching all picking materials:', error)
    ElMessage.error(`獲取所有領料明細失敗: ${error.response?.data || error.message}`)
  } finally {
    loadingPickingMaterials.value = false
  }
}

// Add a new work order
const addWorkOrder = async () => {
  if (!addWorkOrderFormRef.value) return
  addWorkOrderFormRef.value.validate(async (valid) => {
    if (valid) {
      try {
        await http.post<WorkOrderDto>(API_BASE_URL, newWorkOrder.value)
        ElMessage.success('工單新增成功')
        showAddWorkOrderDialog.value = false
        newWorkOrder.value = {
          woNumber: '',
          materialId: null, // 重置為 null
          requiredQuantity: 0,
          status: 'PENDING',
        } // Reset form
        fetchWorkOrders() // Refresh list
      } catch (error: any) {
        console.error('Error adding work order:', error)
        ElMessage.error(`新增工單失敗: ${error.response?.data || error.message}`)
      }
    } else {
      ElMessage.warning('請檢查表單填寫是否正確')
      return false
    }
  })
}

// Delete work order
const deleteWorkOrder = async (id?: number) => {
  if (!id) return
  ElMessageBox.confirm('確定要刪除此工單嗎？', '警告', {
    confirmButtonText: '確定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      try {
        await http.delete(`${API_BASE_URL}/${id}`)
        ElMessage.success('工單刪除成功')
        fetchWorkOrders() // Refresh list
      } catch (error) {
        console.error('Error deleting work order:', error)
        ElMessage.error('刪除工單失敗')
      }
    })
    .catch(() => {
      ElMessage.info('已取消刪除')
    })
}

// View work order details and its materials
const viewWorkOrderDetails = async (workOrder: WorkOrderDto) => {
  selectedWorkOrder.value = workOrder
  showWorkOrderDetailsDialog.value = true
  try {
    const response = await http.get<WorkOrderMaterialDto[]>(`${API_BASE_URL}/${workOrder.woId}/materials`)
    selectedWorkOrderMaterials.value = response.data
  } catch (error) {
    console.error('Error fetching work order materials:', error)
    ElMessage.error('獲取領料明細失敗')
    selectedWorkOrderMaterials.value = []
  }
}

// Process material picking
const processPicking = async () => {
  if (!pickingForm.value.woId || !pickingForm.value.materialId || pickingForm.value.requestedQuantity <= 0) {
    ElMessage.warning('請填寫完整的領料資訊')
    return
  }

  try {
    await http.post(`${API_BASE_URL}/picking`, pickingForm.value);
    ElMessage.success('領料操作成功')
    pickingForm.value = { woId: null, materialId: null, requestedQuantity: 1 } as PickingRequestDto // Reset form
    fetchWorkOrders() // Refresh work order list to see updated stock
    fetchAllPickingMaterials() // 刷新所有領料明細列表
  } catch (error: any) {
    console.error('Error processing picking:', error)
    ElMessage.error(`領料失敗: ${error.response?.data || error.message}`)
  }
}

// 查看領料明細詳情
const viewPickingMaterialDetails = async (pickingMaterial: WorkOrderMaterialDto) => {
  try {
    const response = await http.get<WorkOrderMaterialDto>(`${API_BASE_URL}/materials/${pickingMaterial.woMaterialId}`)
    selectedPickingMaterial.value = response.data
    showPickingMaterialDetailsDialog.value = true
  } catch (error: any) {
    console.error('Error fetching picking material details:', error)
    ElMessage.error(`獲取領料明細詳情失敗: ${error.response?.data || error.message}`)
  }
}

// 刪除領料明細
const deletePickingMaterial = async (id?: number) => {
  if (!id) return
  ElMessageBox.confirm('確定要刪除此領料明細嗎？', '警告', {
    confirmButtonText: '確定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      try {
        await http.delete(`${API_BASE_URL}/materials/${id}`)
        ElMessage.success('領料明細刪除成功')
        fetchAllPickingMaterials() // 刷新列表
      } catch (error: any) {
        console.error('Error deleting picking material:', error)
        ElMessage.error(`刪除領料明細失敗: ${error.response?.data || error.message}`)
      }
    })
    .catch(() => {
      ElMessage.info('已取消刪除')
    })
}

// Picking Order related functions
const addPickingOrderItem = () => {
  newPickingOrder.value.items.push({ materialId: 0, expectedQuantity: 1 });
};

const removePickingOrderItem = (index: number) => {
  newPickingOrder.value.items.splice(index, 1);
};

const resetPickingOrderForm = () => {
  newPickingOrder.value = {
    supplierName: '',
    orderNumber: '',
    expectedReceiptDate: '',
    handledByUserId: undefined,
    status: 'APPROVED',
    note: '',
    items: [],
  };
};

const createPickingOrder = async () => {
  try {
    const payload: any = {
      ...newPickingOrder.value,
      expectedReceiptDate: newPickingOrder.value.expectedReceiptDate ? new Date(newPickingOrder.value.expectedReceiptDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
      handledBy: newPickingOrder.value.handledByUserId ? { userId: newPickingOrder.value.handledByUserId } : null,
      items: newPickingOrder.value.items.map(item => ({
        material: { materialId: item.materialId },
        expectedQuantity: item.expectedQuantity,
      })),
    };
    delete payload.handledByUserId;

    console.log('Sending Picking Order Payload:', payload);
    await http.post<PickingOrder>(PICKING_ORDER_API_BASE_URL, payload);
    ElMessage.success('領料單建立成功');
    showCreatePickingOrderDialog.value = false;
    resetPickingOrderForm();
  } catch (error: any) {
    console.error('Error creating picking order:', error);
    ElMessage.error(`建立領料單失敗: ${error.response?.data?.message || error.message}`);
  }
};
</script>

<style scoped>
.outbound-view {
  padding: 20px;
}

.box-card {
  margin-bottom: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 18px;
  font-weight: bold;
}

.dialog-footer button:first-child {
  margin-right: 10px;
}
</style>
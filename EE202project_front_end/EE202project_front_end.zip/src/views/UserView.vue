<template>
  <div class="user-view">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>員工使用者列表</span>
          <el-button type="primary" @click="openAddUserDialog">新增員工使用者</el-button>
        </div>
      </template>
      <el-table :data="employeeUsers" style="width: 100%" v-loading="loadingUsers">
        <el-table-column prop="employeeUserId" label="ID" width="80"></el-table-column>
        <el-table-column prop="employeeNumber" label="員工編號"></el-table-column>
        <el-table-column prop="firstName" label="名字"></el-table-column>
        <el-table-column prop="lastName" label="姓氏"></el-table-column>
        <el-table-column prop="username" label="使用者名稱"></el-table-column>
        <el-table-column prop="employeeType" label="員工類型"></el-table-column>
        <el-table-column prop="email" label="電子郵件"></el-table-column>
        <el-table-column prop="phone" label="電話"></el-table-column>
        <el-table-column prop="isActive" label="是否啟用" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.isActive ? 'success' : 'danger'">
              {{ scope.row.isActive ? '是' : '否' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180">
          <template #default="scope">
            <el-button link type="primary" size="small" @click="editUser(scope.row)">編輯</el-button>
            <el-button link type="danger" size="small" @click="deleteUser(scope.row.employeeUserId)">刪除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增/編輯員工使用者 Dialog -->
    <el-dialog v-model="showAddUserDialog" :title="isEditMode ? '編輯員工使用者' : '新增員工使用者'" width="600" @close="resetForm">
      <el-form :model="currentEmployeeUser" :rules="formRules" ref="userFormRef" label-width="120px">
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="名字" prop="firstName">
              <el-input v-model="currentEmployeeUser.firstName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="姓氏" prop="lastName">
              <el-input v-model="currentEmployeeUser.lastName"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="員工編號" prop="employeeNumber">
              <el-input v-model="currentEmployeeUser.employeeNumber"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="員工類型" prop="employeeType">
              <el-select v-model="currentEmployeeUser.employeeType" placeholder="選擇員工類型" style="width: 100%;">
                <el-option label="內部" value="INTERNAL"></el-option>
                <el-option label="供應商" value="SUPPLIER"></el-option>
                <el-option label="承包商" value="CONTRACTOR"></el-option>
                <el-option label="系統管理員" value="SYSTEM_ADMIN"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="出生日期">
              <el-date-picker v-model="currentEmployeeUser.birthDate" type="date" placeholder="選擇日期" style="width: 100%;"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="電子郵件" prop="email">
              <el-input v-model="currentEmployeeUser.email"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="電話">
              <el-input v-model="currentEmployeeUser.phone"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="照片路徑">
              <el-input v-model="currentEmployeeUser.photoPath"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="部門ID">
              <el-input v-model="currentEmployeeUser.employeeDepartmentId" type="number"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="職位ID">
              <el-input v-model="currentEmployeeUser.employeePositionId" type="number"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="經理ID">
              <el-input v-model="currentEmployeeUser.managerEmployeeUserId" type="number"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="雇用日期">
              <el-date-picker v-model="currentEmployeeUser.hireDate" type="date" placeholder="選擇日期" style="width: 100%;"></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="解雇日期">
              <el-date-picker v-model="currentEmployeeUser.terminationDate" type="date" placeholder="選擇日期" style="width: 100%;"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="使用者名稱" prop="username">
              <el-input v-model="currentEmployeeUser.username"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="密碼" v-if="!isEditMode" prop="passwordHash">
          <el-input v-model="currentEmployeeUser.passwordHash" type="password" show-password></el-input>
        </el-form-item>
         <!-- 【已修正】增加 prop，使其在編輯模式下也能被驗證 -->
         <el-form-item label="密碼" v-if="isEditMode && showPasswordEdit" prop="passwordHash">
          <el-input v-model="currentEmployeeUser.passwordHash" type="password" show-password placeholder="若不修改請留空"></el-input>
          <el-button type="text" @click="showPasswordEdit = false">取消修改密碼</el-button>
        </el-form-item>
        <el-form-item v-if="isEditMode && !showPasswordEdit">
          <el-button type="text" @click="showPasswordEdit = true">修改密碼</el-button>
        </el-form-item>
        <el-form-item label="是否啟用">
          <el-switch v-model="currentEmployeeUser.is_active"></el-switch>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showAddUserDialog = false">取消</el-button>
          <el-button type="primary" @click="saveEmployeeUser">
            {{ isEditMode ? '更新' : '新增' }}
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted, reactive } from 'vue'
import http from '../http-common'
import { ElMessage, ElMessageBox, FormInstance, FormRules } from 'element-plus'

interface EmployeeUserDto {
  employeeUserId?: number;
  firstName: string;
  lastName: string;
  employeeNumber: string;
  employeeType: 'INTERNAL' | 'SUPPLIER' | 'CONTRACTOR' | 'SYSTEM_ADMIN';
  birthDate?: string;
  email?: string;
  phone?: string;
  photoPath?: string;
  employeeDepartmentId?: number;
  employeePositionId?: number;
  managerEmployeeUserId?: number;
  hireDate?: string;
  terminationDate?: string;
  username?: string;
  passwordHash?: string;
  isActive: boolean;
  lastLogin?: string;
  createdAt?: string;
  updatedAt?: string;
}

const employeeUsers = ref<EmployeeUserDto[]>([])
const loadingUsers = ref(false)
const showAddUserDialog = ref(false)
const isEditMode = ref(false)
const showPasswordEdit = ref(false)

const userFormRef = ref<FormInstance>()

const currentEmployeeUser = ref<EmployeeUserDto>({
  firstName: '',
  lastName: '',
  employeeNumber: '',
  employeeType: 'INTERNAL',
  birthDate: undefined,
  email: '',
  phone: '',
  photoPath: '',
  employeeDepartmentId: undefined,
  employeePositionId: undefined,
  managerEmployeeUserId: undefined,
  hireDate: undefined,
  terminationDate: undefined,
  username: '',
  passwordHash: '',
  isActive: true,
})

// 【已修正】增加自訂驗證器，讓密碼在編輯模式下為非必填
const validatePassword = (rule: any, value: any, callback: any) => {
  // 在「新增」模式下，密碼為必填
  if (!isEditMode.value && !value) {
    callback(new Error('請輸入密碼'));
  } else {
    // 在「編輯」模式下，密碼為選填，所以直接通過
    callback();
  }
};

const formRules = reactive<FormRules>({
  firstName: [{ required: true, message: '請輸入名字', trigger: 'blur' }],
  lastName: [{ required: true, message: '請輸入姓氏', trigger: 'blur' }],
  employeeNumber: [{ required: true, message: '請輸入員工編號', trigger: 'blur' }],
  username: [{ required: true, message: '請輸入使用者名稱', trigger: 'blur' }],
  email: [{ type: 'email', message: '請輸入有效的電子郵件地址', trigger: ['blur', 'change'] }],
  // 【已修正】使用自訂驗證器
  passwordHash: [{ validator: validatePassword, trigger: 'blur' }],
});


const API_BASE_URL = 'http://localhost:8082/api/employee-users'

// Fetch all employee users
const fetchEmployeeUsers = async () => {
  loadingUsers.value = true
  try {
    const response = await http.get<any[]>(API_BASE_URL)
    
    const transformedData = response.data.map(user => {
      if (user.isActive === undefined && user.active !== undefined) {
        user.isActive = user.active;
      }
      return user;
    });

    employeeUsers.value = transformedData as EmployeeUserDto[];

  } catch (error: any) {
    console.error('Error fetching employee users:', error)
    ElMessage.error(`獲取員工使用者列表失敗: ${error.response?.data || error.message}`)
  } finally {
    loadingUsers.value = false
  }
}

const resetForm = () => {
  if (userFormRef.value) {
    userFormRef.value.resetFields();
  }
}

// Open add employee user dialog
const openAddUserDialog = () => {
  isEditMode.value = false
  showPasswordEdit.value = true
  currentEmployeeUser.value = {
    firstName: '',
    lastName: '',
    employeeNumber: '',
    employeeType: 'INTERNAL',
    birthDate: undefined,
    email: '',
    phone: '',
    photoPath: '',
    employeeDepartmentId: undefined,
    employeePositionId: undefined,
    managerEmployeeUserId: undefined,
    hireDate: undefined,
    terminationDate: undefined,
    username: '',
    passwordHash: '',
    is_active: true,
  }
  showAddUserDialog.value = true
  userFormRef.value?.clearValidate();
}

// Save (add/update) employee user
const saveEmployeeUser = async () => {
  if (!userFormRef.value) return;
  await userFormRef.value.validate(async (valid) => {
    if (valid) {
      try {
        const payload: Partial<EmployeeUserDto> = { ...currentEmployeeUser.value };

        if (isEditMode.value && !payload.passwordHash) {
            delete payload.passwordHash;
        }

        if (payload.birthDate instanceof Date) {
          payload.birthDate = payload.birthDate.toISOString().split('T')[0];
        }
        if (payload.hireDate instanceof Date) {
          payload.hireDate = payload.hireDate.toISOString().split('T')[0];
        }
        if (payload.terminationDate instanceof Date) {
          payload.terminationDate = payload.terminationDate.toISOString().split('T')[0];
        }

        if (isEditMode.value) {
          await http.put(`${API_BASE_URL}/${payload.employeeUserId}`, payload);
          ElMessage.success('員工使用者更新成功');
        } else {
          await http.post<EmployeeUserDto>(API_BASE_URL, payload)
          ElMessage.success('員工使用者新增成功')
        }
        showAddUserDialog.value = false
        fetchEmployeeUsers()
      } catch (error: any) {
        console.error('Error saving employee user:', error)
        if (error.response && error.response.status === 409) {
          const conflictMessage = error.response.data?.message || '員工編號、使用者名稱或Email已存在。';
          ElMessage.error(`儲存失敗: ${conflictMessage}`);
        } else {
          const errorMessage = error.response?.data?.message || error.message;
          ElMessage.error(`儲存員工使用者失敗: ${errorMessage}`);
        }
      }
    } else {
      ElMessage.error('表單驗證失敗，請檢查輸入的資料！');
      return false;
    }
  });
}

// Edit employee user
const editUser = (user: EmployeeUserDto) => {
  isEditMode.value = true
  showPasswordEdit.value = false
  currentEmployeeUser.value = {
    ...user,
    passwordHash: '',
    birthDate: user.birthDate ? new Date(user.birthDate) : undefined,
    hireDate: user.hireDate ? new Date(user.hireDate) : undefined,
    terminationDate: user.terminationDate ? new Date(user.terminationDate) : undefined,
  }
  showAddUserDialog.value = true
  userFormRef.value?.clearValidate();
}

// Delete employee user
const deleteUser = async (id?: number) => {
  if (!id) return
  ElMessageBox.confirm('確定要刪除此員工使用者嗎？', '警告', {
    confirmButtonText: '確定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      try {
        await http.delete(`${API_BASE_URL}/${id}`)
        ElMessage.success('員工使用者刪除成功')
        fetchEmployeeUsers()
      } catch (error: any) {
        console.error('Error deleting employee user:', error)
        ElMessage.error(`刪除員工使用者失敗: ${error.response?.data || error.message}`)
      }
    })
    .catch(() => {
      ElMessage.info('已取消刪除')
    })
}

onMounted(() => {
  fetchEmployeeUsers()
})
</script>

<style scoped>
.user-view {
  padding: 20px;
}

.box-card {
  margin-bottom: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 18px;
  font-weight: bold;
}

.dialog-footer button:first-child {
  margin-right: 10px;
}
</style>

<template>
  <div class="supplier-view">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>供應商管理</span>
          <el-button type="primary" @click="showAddSupplierDialog = true">新增供應商</el-button>
        </div>
      </template>
      <el-table :data="suppliers" style="width: 100%" v-loading="loadingSuppliers">
        <el-table-column prop="supplierId" label="ID" width="80"></el-table-column>
        <el-table-column prop="supplierName" label="供應商名稱"></el-table-column>
        <el-table-column prop="pm" label="聯絡人"></el-table-column>
        <el-table-column prop="supplierPhone" label="電話"></el-table-column>
        <el-table-column prop="supplierEmail" label="電子郵件"></el-table-column>
        <el-table-column prop="supplierAddress" label="地址"></el-table-column>
        <el-table-column prop="active" label="啟用" width="80">
          <template #default="scope">
            <el-tag :type="scope.row.active ? 'success' : 'danger'">{{ scope.row.active ? '是' : '否' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150">
          <template #default="scope">
            <el-button link type="primary" size="small" @click="editSupplier(scope.row)">編輯</el-button>
            <el-button link type="danger" size="small" @click="deleteSupplier(scope.row.supplierId)">刪除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增/編輯供應商 Dialog -->
    <el-dialog v-model="showAddSupplierDialog" :title="isEditMode ? '編輯供應商' : '新增供應商'" width="600">
      <el-form :model="currentSupplier" label-width="120px">
        <el-form-item label="供應商名稱">
          <el-input v-model="currentSupplier.supplierName"></el-input>
        </el-form-item>
        <el-form-item label="聯絡人">
          <el-input v-model="currentSupplier.pm"></el-input>
        </el-form-item>
        <el-form-item label="電話">
          <el-input v-model="currentSupplier.supplierPhone"></el-input>
        </el-form-item>
        <el-form-item label="電子郵件">
          <el-input v-model="currentSupplier.supplierEmail"></el-input>
        </el-form-item>
        <el-form-item label="地址">
          <el-input v-model="currentSupplier.supplierAddress" type="textarea"></el-input>
        </el-form-item>
        <el-form-item label="是否啟用">
          <el-switch v-model="currentSupplier.active"></el-switch>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showAddSupplierDialog = false">取消</el-button>
          <el-button type="primary" @click="saveSupplier">
            {{ isEditMode ? '更新' : '新增' }}
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue'
import http from '../http-common'
import { ElMessage, ElMessageBox } from 'element-plus'

interface Supplier {
  supplierId?: number;
  supplierName: string;
  pm: string;
  supplierPhone: string;
  supplierEmail: string;
  supplierAddress: string;
  active: boolean;
}

const suppliers = ref<Supplier[]>([])
const loadingSuppliers = ref(false)
const showAddSupplierDialog = ref(false)
const isEditMode = ref(false)
const currentSupplier = ref<Supplier>({
  supplierName: '',
  pm: '',
  supplierPhone: '',
  supplierEmail: '',
  supplierAddress: '',
  active: true,
})

const API_BASE_URL = 'http://localhost:8082/api/supplier'

// Fetch all suppliers
const fetchSuppliers = async () => {
  loadingSuppliers.value = true
  try {
    const response = await http.get<Supplier[]>(API_BASE_URL)
    suppliers.value = response.data
  } catch (error) {
    console.error('Error fetching suppliers:', error)
    ElMessage.error('獲取供應商列表失敗')
  } finally {
    loadingSuppliers.value = false
  }
}

// Save (add/update) a supplier
const saveSupplier = async () => {
  try {
    if (isEditMode.value) {
      await http.put(`${API_BASE_URL}/${currentSupplier.value.supplierId}`, currentSupplier.value)
      ElMessage.success('供應商更新成功')
    } else {
      await http.post<Supplier>(API_BASE_URL, currentSupplier.value)
      ElMessage.success('供應商新增成功')
    }
    showAddSupplierDialog.value = false
    resetForm() // Reset form
    fetchSuppliers() // Refresh list
  } catch (error) {
    console.error('Error saving supplier:', error)
    ElMessage.error('儲存供應商失敗')
  }
}

// Edit supplier
const editSupplier = (supplier: Supplier) => {
  isEditMode.value = true
  currentSupplier.value = { ...supplier } // Deep copy
  showAddSupplierDialog.value = true
}

// Delete supplier
const deleteSupplier = async (id?: number) => {
  if (!id) return
  ElMessageBox.confirm('確定要刪除此供應商嗎？', '警告', {
    confirmButtonText: '確定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      try {
        await http.delete(`${API_BASE_URL}/${id}`)
        ElMessage.success('供應商刪除成功')
        fetchSuppliers() // Refresh list
      } catch (error) {
        console.error('Error deleting supplier:', error)
        ElMessage.error('刪除供應商失敗')
      }
    })
    .catch(() => {
      ElMessage.info('已取消刪除')
    })
}

// Reset form fields
const resetForm = () => {
  isEditMode.value = false
  currentSupplier.value = {
    supplierName: '',
    pm: '',
    supplierPhone: '',
    supplierEmail: '',
    supplierAddress: '',
    active: true,
  }
}

onMounted(() => {
  fetchSuppliers()
})
</script>

<style scoped>
.supplier-view {
  padding: 20px;
}

.box-card {
  margin-bottom: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 18px;
  font-weight: bold;
}

.dialog-footer button:first-child {
  margin-right: 10px;
}
</style>

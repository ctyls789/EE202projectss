import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import { useAuthStore } from '../stores/AuthStore' // Import the auth store

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
      meta: { requiresAuth: true } // Protect this route
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('../views/LoginView.vue') // Lazy load LoginView
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (About.[hash].js) for this route
      // which lazy-loaded when the route is visited.
      component: () => import('../views/AboutView.vue'),
      meta: { requiresAuth: true } // Protect this route
    },
    {
      path: '/products',
      name: 'products',
      // route level code-splitting
      // this generates a separate chunk (Products.[hash].js) for this route
      // which lazy-loaded when the route is visited.
      component: () => import('../views/ProductsView.vue'),
      meta: { requiresAuth: true } // Protect this route
    },
    {
      path: '/depot',
      name: 'depot',
      component: () => import('../views/DepotView.vue'),
      meta: { requiresAuth: true } // Protect this route
    },
    {
      path: '/suppliers',
      name: 'suppliers',
      component: () => import('../views/SupplierView.vue'),
      meta: { requiresAuth: true } // Protect this route
    },
    {
      path: '/outbound',
      name: 'outbound',
      component: () => import('../views/OutboundView.vue'),
      meta: { requiresAuth: true } // Protect this route
    },
    {
      path: '/inventory-logs',
      name: 'inventory-logs',
      component: () => import('../views/InventoryLogView.vue'),
      meta: { requiresAuth: true } // Protect this route
    },
    {
      path: '/inventory',
      name: 'inventory',
      component: () => import('../views/InventoryLogView.vue'),
      meta: { requiresAuth: true } // Protect this route
    },
    {
      path: '/users',
      name: 'users',
      component: () => import('../views/UserView.vue'),
      meta: { requiresAuth: true } // Protect this route
    },
    {
      path: '/profile',
      name: 'profile',
      component: () => import('../views/UserProfileView.vue'),
      meta: { requiresAuth: true } // Protect this route
    }
  ],
})

router.beforeEach((to, from, next) => {
  const authStore = useAuthStore();
  const publicPages = ['/login']; // Pages that don't require authentication
  const authRequired = !publicPages.includes(to.path);
  const loggedIn = authStore.loggedIn;

  if (authRequired && !loggedIn) {
    next('/login'); // Redirect to login page if not logged in and trying to access a protected page
  } else {
    next(); // Continue to the requested page
  }
});

export default router

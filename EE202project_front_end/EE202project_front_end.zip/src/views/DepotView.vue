<template>
  <div class="depot-view">
    <el-row :gutter="20">
      <el-col :span="12">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>物料列表 (庫存)</span>
              <el-button type="primary" @click="openAddMaterialDialog">新增物料</el-button>
            </div>
          </template>
          <el-table :data="materials" style="width: 100%" v-loading="loadingMaterials">
            <el-table-column prop="materialId" label="ID" width="80"></el-table-column>
            <el-table-column prop="materialName" label="物料名稱"></el-table-column>
            <el-table-column prop="stockCurrent" label="庫存數量" width="120"></el-table-column>
            <el-table-column prop="unit" label="單位" width="80"></el-table-column>
            <el-table-column label="操作" width="150">
              <template #default="scope">
                <el-button link type="primary" size="small" @click="editMaterial(scope.row)">編輯</el-button>
                <el-button link type="danger" size="small" @click="deleteMaterial(scope.row.materialId)">刪除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>

      <el-col :span="12">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>入庫單列表</span>
              <el-button type="primary" @click="showCreateInboundReceiptDialog = true; fetchAvailableMaterialsForInbound(); newInboundReceipt.handledBy = 'admin';">建立入庫單</el-button>
              
            </div>
          </template>
          <el-table :data="inboundReceipts" style="width: 100%" v-loading="loadingInboundReceipts">
            <el-table-column prop="inboundId" label="ID" width="80"></el-table-column>
            <el-table-column prop="inboundDate" label="入庫日期"></el-table-column>
            <el-table-column prop="status" label="狀態" width="100">
              <template #default="scope">
                <el-tag :type="scope.row.status === 'COMPLETED' ? 'success' : 'info'">
                  {{ scope.row.status }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="handledBy" label="經手人" width="100"></el-table-column>
            <el-table-column prop="note" label="備註"></el-table-column>
            <el-table-column label="操作" width="150">
              <template #default="scope">
                <el-button link type="primary" size="small" @click="viewInboundReceiptDetails(scope.row)">詳情</el-button>
                <el-button link type="danger" size="small" @click="deleteInboundReceipt(scope.row.inboundId)">刪除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <!-- 新增/編輯物料 Dialog -->
    <el-dialog v-model="showAddMaterialDialog" :title="isEditMode ? '編輯物料' : '新增物料'" width="700">
      <el-form :model="currentMaterial" label-width="100px">
        <el-form-item label="物料ID" v-if="isEditMode">
          <el-input v-model="currentMaterial.materialId" disabled></el-input>
        </el-form-item>
        <el-form-item label="物料名稱">
          <el-input v-model="currentMaterial.materialName"></el-input>
        </el-form-item>
        <el-form-item label="單位">
          <el-input v-model="currentMaterial.unit"></el-input>
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="currentMaterial.materialDescription" type="textarea"></el-input>
        </el-form-item>
        <el-form-item label="儲位">
          <el-input v-model="currentMaterial.location"></el-input>
        </el-form-item>
        <el-form-item label="安全庫存">
          <el-input-number v-model="currentMaterial.safetyStock" :min="0"></el-input-number>
        </el-form-item>
        <el-form-item label="再訂購點">
          <el-input-number v-model="currentMaterial.reorderLevel" :min="0"></el-input-number>
        </el-form-item>
        <el-form-item label="是否啟用">
          <el-switch v-model="currentMaterial.active"></el-switch>
        </el-form-item>
        <!-- 庫存數量不直接在新增/編輯介面修改，而是透過入庫/出庫 -->
        <!-- <el-form-item label="庫存數量">
          <el-input-number v-model="currentMaterial.stockCurrent" :min="0"></el-input-number>
        </el-form-item> -->
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showAddMaterialDialog = false">取消</el-button>
          <el-button type="primary" @click="saveMaterial">
            {{ isEditMode ? '更新' : '新增' }}
          </el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 建立入庫單 Dialog -->
    <el-dialog v-model="showCreateInboundReceiptDialog" title="建立入庫單" width="600">
      <el-form :model="newInboundReceipt" label-width="120px">
        <el-form-item label="入庫日期">
          <el-date-picker v-model="newInboundReceipt.inboundDate" type="date" placeholder="選擇日期" style="width: 100%;"></el-date-picker>
        </el-form-item>
        <el-form-item label="關聯領料單">
          <el-select v-model="newInboundReceipt.pickingOrderId" placeholder="選擇領料單 (可選)" clearable style="width: 100%;">
            <el-option
              v-for="order in pickingOrdersForInbound"
              :key="order.pickingOrderId"
              :label="`領料單ID: ${order.pickingOrderId} - ${order.supplierName} (${order.orderNumber})`"
              :value="order.pickingOrderId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="狀態">
          <el-select v-model="newInboundReceipt.status" placeholder="選擇狀態">
            <el-option label="草稿" value="DRAFT"></el-option>
            <el-option label="已完成" value="COMPLETED"></el-option>
            <el-option label="已取消" value="CANCELLED"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="經手人">
          <el-select v-model.number="newInboundReceipt.handledByUserId" placeholder="選擇經手人" style="width: 100%;">
            <el-option
              v-for="user in users"
              :key="user.userId"
              :label="user.username"
              :value="user.userId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="備註">
          <el-input v-model="newInboundReceipt.note" type="textarea" placeholder="輸入備註"></el-input>
        </el-form-item>
        <el-form-item label="入庫項目">
          <el-button type="primary" link @click="addInboundReceiptItem">新增項目</el-button>
          <el-table :data="newInboundReceipt.items" style="width: 100%; margin-top: 10px;">
            <el-table-column label="物料ID">
              <template #default="scope">
                <el-select v-model.number="scope.row.materialId" placeholder="選擇物料">
                  <el-option
                    v-for="mat in availableMaterialsForInbound"
                    :key="mat.materialId"
                    :label="`${mat.materialName} (ID: ${mat.materialId})`"
                    :value="mat.materialId"
                  ></el-option>
                </el-select>
              </template>
            </el-table-column>
            <el-table-column label="數量">
              <template #default="scope">
                <el-input-number v-model="scope.row.receivedQuantity" :min="1"></el-input-number>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="80">
              <template #default="scope">
                <el-button link type="danger" @click="removeInboundReceiptItem(scope.$index)">刪除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showCreateInboundReceiptDialog = false">取消</el-button>
          <el-button type="primary" @click="createInboundReceipt">
            建立
          </el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 入庫單詳情 Dialog -->
    <el-dialog v-model="showInboundReceiptDetailsDialog" title="入庫單詳情" width="600">
      <div v-if="selectedInboundReceipt" class="inbound-details-content">
        <p><strong>ID:</strong> {{ selectedInboundReceipt.inboundId }}</p>
        <p><strong>入庫日期:</strong> {{ selectedInboundReceipt.inboundDate }}</p>
        <p><strong>狀態:</strong> {{ selectedInboundReceipt.status }}</p>
        <p v-if="selectedInboundReceipt.handledBy"><strong>經手人:</strong> {{ selectedInboundReceipt.handledBy }}</p>
        <p v-if="selectedInboundReceipt.note"><strong>備註:</strong> {{ selectedInboundReceipt.note }}</p>
        <h4>入庫項目:</h4>
        <el-table :data="selectedInboundReceipt.items" style="width: 100%">
          <el-table-column prop="materialId" label="物料ID"></el-table-column>
          <el-table-column prop="materialName" label="物料名稱"></el-table-column>
          <el-table-column prop="receivedQuantity" label="數量"></el-table-column>
        </el-table>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showInboundReceiptDetailsDialog = false">關閉</el-button>
        </span>
      </template>
    </el-dialog>

    
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted, watch } from 'vue'
import http from '../http-common'
import { ElMessage, ElMessageBox } from 'element-plus' // 引入 ElMessageBox

interface UserDto {
  userId: number;
  username: string;
  fullName: string;
}

interface Material {
  materialId?: number;
  materialName: string;
  stockCurrent: number;
  unit: string;
  materialDescription?: string; // 新增欄位
  location?: string; // 新增欄位
  safetyStock?: number | null; // 允許為 null
  reorderLevel?: number | null; // 允許為 null
  active?: boolean; // 新增欄位
}

interface InboundReceiptItem {
  materialId: number;
  receivedQuantity: number; // 修正：將 quantity 改為 receivedQuantity
}

interface InboundReceipt {
  inboundId?: number;
  inboundDate: string; // Changed from receiptDate to inboundDate
  status: string;
  handledBy?: string; // 將 handler 改為 handledBy
  note?: string; // 將 remarks 改為 note
  items: InboundReceiptItem[];
  pickingOrderId?: number | null;
  handledByUserId?: number;
}

// Add Picking Order interfaces
interface PickingOrderItem {
  materialId: number;
  expectedQuantity: number;
  // Assuming other properties might exist but are not used in this component
}

interface PickingOrder {
  pickingOrderId: number;
  supplierName: string; // From the template label
  orderNumber: string; // From the template label
  items: PickingOrderItem[];
}


const users = ref<UserDto[]>([]); // 新增：用於經手人下拉選單
const materials = ref<Material[]>([])
const inboundReceipts = ref<InboundReceipt[]>([])
const pickingOrdersForInbound = ref<PickingOrder[]>([]); // For the picking order dropdown
const loadingMaterials = ref(false)
const loadingInboundReceipts = ref(false)

const showAddMaterialDialog = ref(false)
const isEditMode = ref(false) // 新增：判斷是否為編輯模式
const currentMaterial = ref<Material>({ // 將 newMaterial 改為 currentMaterial
  materialName: '',
  stockCurrent: 0,
  unit: '',
  materialDescription: '',
  location: '',
  safetyStock: 0,
  reorderLevel: 0,
  active: true,
})

const showCreateInboundReceiptDialog = ref(false)
const newInboundReceipt = ref<InboundReceipt>({ 
  inboundDate: '', // Initialize as empty string
  status: 'COMPLETED', // 預設為 COMPLETED
  handledByUserId: undefined, // Initialize with undefined
  note: '', // 將 remarks 改為 note
  items: [],
  pickingOrderId: null, // Initialize pickingOrderId
})

const showInboundReceiptDetailsDialog = ref(false)
const selectedInboundReceipt = ref<InboundReceipt | null>(null)

const API_BASE_URL = 'http://localhost:8082/api/depot' // Adjust if your API is on a different base path
const USER_API_BASE_URL = 'http://localhost:8082/api/employee-users' // 新增：使用者 API 路徑
const PICKING_ORDER_API_BASE_URL = 'http://localhost:8082/api/picking-orders'; // API for picking orders

// Fetch all users for dropdown
const fetchUsersForDropdown = async () => {
  try {
    const response = await http.get<UserDto[]>(USER_API_BASE_URL);
    users.value = response.data;
  } catch (error: any) {
    console.error('Error fetching users for dropdown:', error);
    ElMessage.error(`獲取使用者列表失敗: ${error.response?.data?.message || error.message}`);
  }
};

// Fetch all materials
const fetchMaterials = async () => {
  loadingMaterials.value = true
  try {
    const response = await http.get<Material[]>(`${API_BASE_URL}/materials`)
    materials.value = response.data
  } catch (error: any) {
    console.error('Error fetching materials:', error)
    ElMessage.error(`獲取物料列表失敗: ${error.response?.data || error.message}`)
  } finally {
    loadingMaterials.value = false
  }
}

// 打開新增物料對話框
const openAddMaterialDialog = () => {
  isEditMode.value = false;
  resetMaterialForm();
  showAddMaterialDialog.value = true;
}

// 儲存 (新增/更新) 物料
const saveMaterial = async () => {
  try {
    if (isEditMode.value) {
      // 更新物料
      await http.put(`${API_BASE_URL}/materials/${currentMaterial.value.materialId}`, currentMaterial.value)
      ElMessage.success('物料更新成功')
    } else {
      // 新增物料
      await http.post<Material>(`${API_BASE_URL}/materials`, currentMaterial.value)
      ElMessage.success('物料新增成功')
    }
    showAddMaterialDialog.value = false
    fetchMaterials() // Refresh list
  } catch (error: any) {
    console.error('Error saving material:', error)
    ElMessage.error(`儲存物料失敗: ${error.response?.data || error.message}`)
  }
}

// 編輯物料
const editMaterial = (material: Material) => {
  isEditMode.value = true;
  currentMaterial.value = { ...material }; // 深度複製物料資料到表單
  showAddMaterialDialog.value = true;
}

// 刪除物料
const deleteMaterial = async (id?: number) => {
  if (!id) return
  ElMessageBox.confirm('確定要刪除此物料嗎？', '警告', {
    confirmButtonText: '確定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      try {
        await http.delete(`${API_BASE_URL}/materials/${id}`)
        ElMessage.success('物料刪除成功')
        fetchMaterials() // Refresh list
      } catch (error: any) {
        console.error('Error deleting material:', error)
        ElMessage.error(`刪除物料失敗: ${error.response?.data || error.message}`)
      }
    })
    .catch(() => {
      ElMessage.info('已取消刪除')
    })
}

// 刪除入庫單
const deleteInboundReceipt = async (id?: number) => {
  if (!id) return
  ElMessageBox.confirm('確定要刪除此入庫單嗎？', '警告', {
    confirmButtonText: '確定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      try {
        await http.delete(`${API_BASE_URL}/inbound-receipts/${id}`)
        ElMessage.success('入庫單刪除成功')
        fetchInboundReceipts() // Refresh list
      } catch (error: any) {
        console.error('Error deleting inbound receipt:', error)
        ElMessage.error(`刪除入庫單失敗: ${error.response?.data || error.message}`)
      }
    })
    .catch(() => {
      ElMessage.info('已取消刪除')
    })
}


// 重置物料表單
const resetMaterialForm = () => {
  currentMaterial.value = {
    materialName: '',
    stockCurrent: 0,
    unit: '',
    materialDescription: '',
    location: '',
    safetyStock: 0,
    reorderLevel: 0,
    active: true,
  }
}

// Fetch all inbound receipts
const fetchInboundReceipts = async () => {
  loadingInboundReceipts.value = true;
  try {
    const response = await http.get<any>(`${API_BASE_URL}/inbound-receipts`);

    // --- DEBUGGING STEP ---
    // This will show us the exact structure of the server response in the browser's developer console (F12).
    console.log('Server response for inbound receipts:', response.data);

    // It's very likely the array is nested. Let's try to access it.
    // Common structures are response.data or response.data.data
    const receiptsData = response.data.data || response.data; 

    if (Array.isArray(receiptsData)) {
      inboundReceipts.value = receiptsData.map(receipt => {
        const date = receipt.inboundDate || receipt.receiptDate; // Handle both possible date fields
        return {
          inboundId: receipt.inboundId || 0,
          inboundDate: date ? new Date(date).toLocaleDateString('zh-TW') : '',
          status: receipt.status || 'N/A',
          handledBy: receipt.handledBy || '', // 映射後端 handledBy 到前端 handledBy
          note: receipt.note || '',
          items: [] // 避免無限遞迴，只在詳情頁面獲取具體項目
        };
      });
    } else {
      console.warn('The received data is not an array!', receiptsData);
      inboundReceipts.value = []; // Clear the table if data is invalid
    }

  } catch (error: any) {
    console.error('Error fetching inbound receipts:', error);
    ElMessage.error(`獲取入庫單列表失敗: ${error.response?.data?.message || error.message}`);
  } finally {
    loadingInboundReceipts.value = false;
  }
};

// Add an item to the new inbound receipt form
const addInboundReceiptItem = () => {
  newInboundReceipt.value.items.push({ materialId: 0, receivedQuantity: 1 }) // Initialize with a default materialId, e.g., 0 or the first available material's ID
}

// Remove an item from the new inbound receipt form
const removeInboundReceiptItem = (index: number) => {
  newInboundReceipt.value.items.splice(index, 1)
}

// Create a new inbound receipt
const createInboundReceipt = async () => {
  const resetForm = () => {
    newInboundReceipt.value = { 
      inboundDate: '', 
      status: 'COMPLETED', 
      items: [],
      pickingOrderId: null,
      handledByUserId: undefined,
      note: ''
    };
  }

  try {
    const validItems = newInboundReceipt.value.items.filter(item => item.materialId && item.receivedQuantity > 0);
    if (validItems.length === 0) {
      ElMessage.warning('請至少新增一個有效的入庫項目');
      return;
    }

    const payload: any = {
      ...newInboundReceipt.value,
      inboundDate: newInboundReceipt.value.inboundDate ? new Date(newInboundReceipt.value.inboundDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
      pickingOrderId: newInboundReceipt.value.pickingOrderId || null,
      handledBy: newInboundReceipt.value.handledByUserId ? { userId: newInboundReceipt.value.handledByUserId } : null,
      items: validItems
    };
    
    delete payload.handledByUserId;

    console.log('Sending Inbound Receipt Payload:', payload);
    await http.post<InboundReceipt>(`${API_BASE_URL}/inbound-receipts`, payload)
    ElMessage.success('入庫單建立成功')
    showCreateInboundReceiptDialog.value = false;
    resetForm();
    fetchInboundReceipts()
    fetchMaterials();
  } catch (error: any) {
    console.error('Error creating inbound receipt:', error)
    ElMessage.error(`建立入庫單失敗: ${error.response?.data?.message || error.message}`)
  }
}


// View inbound receipt details
const viewInboundReceiptDetails = async (receipt: InboundReceipt) => {
  try {
    const response = await http.get<any>(`${API_BASE_URL}/inbound-receipts/${receipt.inboundId}`)
    const date = response.data.inboundDate || response.data.receiptDate;
    selectedInboundReceipt.value = {
      inboundId: response.data.inboundId || 0,
      inboundDate: date ? new Date(date).toLocaleDateString('zh-TW') : '',
      status: response.data.status || 'N/A',
      handledBy: response.data.handledBy || '',
      note: response.data.note || '',
      items: (response.data.items || []).map((item: any) => {
        const material = availableMaterialsForInbound.value.find(mat => mat.materialId === item.materialId);
        return {
          ...item,
          materialName: material ? material.materialName : '未知物料'
        };
      })
    }
    showInboundReceiptDetailsDialog.value = true
  } catch (error: any) {
    console.error('Error fetching inbound receipt details:', error)
    ElMessage.error(`獲取入庫單詳情失敗: ${error.response?.data || error.message}`)
  }
}

// 新增：用於入庫單選擇的物料列表
const availableMaterialsForInbound = ref<Material[]>([]);
const fetchAvailableMaterialsForInbound = async () => {
  try {
    const response = await http.get<Material[]>(`${API_BASE_URL}/materials`);
    availableMaterialsForInbound.value = response.data;
  } catch (error: any) {
    console.error('Error fetching available materials for inbound:', error);
    ElMessage.error(`獲取可用物料列表失敗: ${error.response?.data || error.message}`);
  }
};

const fetchPickingOrdersForInbound = async () => {
  try {
    const response = await http.get<PickingOrder[]>(PICKING_ORDER_API_BASE_URL, {
      params: { status: 'APPROVED' } // Fetch only approved picking orders
    });
    pickingOrdersForInbound.value = response.data.map(order => ({
      pickingOrderId: order.pickingOrderId,
      supplierName: order.supplierName || 'N/A', // Ensure supplierName is present
      orderNumber: order.orderNumber || 'N/A',   // Ensure orderNumber is present
      items: order.items || []
    }));
  } catch (error: any) {
    console.error('Error fetching picking orders for inbound:', error);
    ElMessage.warning('無法獲取可關聯的領料單列表，但您仍可手動建立入庫單。');
  }
};



onMounted(() => {
  fetchMaterials()
  fetchInboundReceipts()
  fetchAvailableMaterialsForInbound();
  fetchUsersForDropdown();
  fetchPickingOrdersForInbound();
})

watch(() => newInboundReceipt.value.pickingOrderId, (newPickingOrderId) => {
  if (newPickingOrderId) {
    const selectedOrder = pickingOrdersForInbound.value.find(order => order.pickingOrderId === newPickingOrderId);
    if (selectedOrder) {
      newInboundReceipt.value.items = selectedOrder.items.map(item => ({
        materialId: item.material.materialId, // Access material.materialId
        receivedQuantity: item.expectedQuantity,
      }));
    }
  } else {
    newInboundReceipt.value.items = [];
  }
});
</script>

<style scoped>
.depot-view {
  padding: 20px;
}

.box-card {
  margin-bottom: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 18px;
  font-weight: bold;
}

.dialog-footer button:first-child {
  margin-right: 10px;
}

/* 增加選擇器權重，確保樣式生效 */
.el-dialog__body .inbound-details-content p {
  margin-bottom: 5px !important; /* 調整這個值來控制行距 */
}

.el-dialog__body .inbound-details-content h4 {
  margin-top: 15px !important; /* 調整標題上方的間距 */
  margin-bottom: 10px !important; /* 調整標題下方的間距 */
}
</style>
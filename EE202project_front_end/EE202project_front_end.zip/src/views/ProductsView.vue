<template>
  <div>
    <h1>Our Products</h1>
    <el-table :data="products" style="width: 100%">
      <el-table-column prop="name" label="Name" />
      <el-table-column prop="price" label="Price" />
      <el-table-column prop="category" label="Category" />
    </el-table>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'

const products = ref([
  { name: 'Product A', price: 100, category: 'Category 1' },
  { name: 'Product B', price: 150, category: 'Category 1' },
  { name: 'Product C', price: 200, category: 'Category 2' },
  { name: 'Product D', price: 250, category: 'Category 2' },
])
</script>
